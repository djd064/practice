<?php
 // This provides the header displayed on all Pages
?> 
<DIV>
<table id="myheader">
<tbody>
<tr>
   <td><img src="Images/umuc_logo.jpg" alt="UMUC logo"/></td>  
   <td>CS Tutor</td>   
</tr>
</tbody>
</table>
</DIV>
<?php
?>